# legaljr-server-backend
 Flask, Python, and machine learning used to convert legal judgments from PDF to TXT, summarize them, and recommend previously similar documents.
